import React from 'react';
import Input from './Input';

const Mother = ({onClick,count}) => {
  return (
    <>
      <Input
      label="Mother's Input"
      button={{
        submit:"plus",
        cancel:"minos"
      }}
      input={{
        id:"mothers-input",
        min: 0,
        max: 10,
        type: 'number',
        value:count,
        placeholder: 'please wrtie any words...'
      }}
      func={onClick}
      />
      
    </>
  );
};

export default Mother;