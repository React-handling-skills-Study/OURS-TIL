import React from 'react';

const CartTemplate = () => {
  return (
    <div>
      
    </div>
  );
};

export default CartTemplate;