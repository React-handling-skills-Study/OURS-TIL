import React from 'react';
import { useParams } from 'react-router-dom';

const NewMemberMessage = () => {

  const params = useParams()
  const {newmemberId} = params;
  console.log(newmemberId);
  return (
    <div>
      {newmemberId}
    </div>
  );
};

export default NewMemberMessage;