import React from 'react';
import { Description } from './About';
const Contect = () => {
  return (
    <div>
      <h1 style={{
        marginTop: '2rem'
      }}>Contect M.I</h1>
      <Description>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi ab asperiores voluptatem dolor ea quia voluptas distinctio illo. Corrupti, excepturi quis? Ipsam quis libero quam dolorem, vitae illum harum nihil, itaque a suscipit eius dignissimos iste praesentium amet delectus culpa laborum eum numquam temporibus reprehenderit necessitatibus. Similique recusandae corrupti necessitatibus repellat eius saepe odio sed esse omnis. Ab, excepturi temporibus? Amet corporis enim placeat. Voluptatum fugit alias eveniet doloremque aut voluptas dolorem maxime nam, laborum culpa dolore! Nihil maiores accusantium est sit qui quidem, vitae aut, nostrum deserunt dolor ipsam autem adipisci nam eaque animi consequatur veritatis. Quo, natus obcaecati? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quam quod necessitatibus laboriosam. Rerum est omnis eius numquam dicta, saepe explicabo delectus vero molestias vitae voluptates cupiditate aperiam recusandae culpa alias.</Description>
    </div>
  );
};

export default Contect;