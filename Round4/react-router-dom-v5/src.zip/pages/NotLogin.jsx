import React from 'react';

const NotLogin = () => {
  return (
    <div>
      loginplease
    </div>
  );
};

export default NotLogin;